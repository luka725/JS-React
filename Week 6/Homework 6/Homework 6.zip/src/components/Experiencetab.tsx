import Expdesc from "./Expdesc";

function Experiencetab() {
    return(
    <section className="mainexpwrapper">
        <div className="titlewrapper">
            <h1 className="title">Experience</h1>
        </div>
        <Expdesc />
        <button className="btn">More info</button>
    </section>
    )
}
export default Experiencetab;