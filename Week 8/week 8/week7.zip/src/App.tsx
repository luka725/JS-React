import './App.css'
import Person from './Components/Person'

function App() {

  return (
    <div className="App">
      <Person />
    </div>
  )
}

export default App
